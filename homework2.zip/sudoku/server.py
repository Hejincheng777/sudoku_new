import copy
import threading

from flask import Flask, render_template
from generate import generate, remove

app = Flask(__name__)

@app.route('/')
def index():

    # 创建一个空列表用于保存生成的九个数独谜题
    sudokus = []

    # 定义生成数独的函数
    def generate_sudoku():
        sudoku = generate()
        fillhole = copy.deepcopy(sudoku)
        remove(fillhole, 45)
        return (sudoku, fillhole)

    # 创建九个线程，每个线程生成一个数独谜题并将其保存到列表中
    threads = []
    for _ in range(9):
        thread = threading.Thread(target=lambda: sudokus.append(generate_sudoku()))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return render_template('new.html', sudokus=sudokus)


if __name__ == '__main__':

    app.run()
